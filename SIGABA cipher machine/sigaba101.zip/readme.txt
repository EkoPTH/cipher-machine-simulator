Installing The SIGABA simulator.

This program requires at least 800x600 resolution and 16 bit or more colors.
To install, run the program INSTALL.EXE The destination directory can
be changed if necessary. Note this directory is restricted to a maximum 
of 8 letters. 
The install utility should work with Windows 3.1x/95/98/NT4 and Win2000
The Install program will create the destination directory and copy 
the required files to the destination directory and optionally set
up a program group or Taskbar item. 
No Registry operations or DLL files are involved in installation.
To uninstall either re-run the Install program and check the Uninstall
box or manually delete the files and program group. 
Uninstall may require manual deletion of some components.


