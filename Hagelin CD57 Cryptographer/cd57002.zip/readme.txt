CD-57 Simulator		(First version build 001) April 2000

1. Program is best run at 800 pixels or greater resolution. I have tested on 800x600 and 1024x768 but not 640x480. It seems to be OK on Win95 and Win2000. Not yet tested on Win3.1x or NT4.

2. On start up a default key file is loaded <startup.key>. There is no INI file or bitmap image (yet).

3. On exit startup.key is over-written with the current settings - if you want to preserve a setting then use Save key from the file menu before exit.

4. Pin-wheel  pins can be set by holding down Ctrl key and clicking pins with mouse - they will toggle on/off. Pins can only be changed when the Pin-wheel position is 'A' (note there is currently no indication of pin position 01. The Pin-wheels are viewed as seen in the machine with the white wheel identification number on the upper side - pins are 'X-ray' views. The key files (*.key) can also be edited with a text editor. Key files must be in the form shown (same as Michael Topf's program). Some error checking is done when the key is loaded, but fields must be in thie order shown

5. Pin-wheel positions can be set by holding down the Shift key and clicking within the Pin-wheel. Wheels will move CW or CCW, depending on which side of the wheel is clicked on.

6. Lug-wheel settings can be changed by holding down the Ctrl key and selecting a lug position with the mouse.

7. Alphabet outer disc can be set with the mouse, holding down the Shift key and click in the top left or top right section of the window.

8. Operation is by pressing a key A-Z, the key simulates the action of the operating lever (keyboard repeat is suppressed). Pin-wheels will move and Alphabet disc move to new position. The plain and enciphered letter is placed in the Message windows.

9. Most other program options are as for the other simulators.
